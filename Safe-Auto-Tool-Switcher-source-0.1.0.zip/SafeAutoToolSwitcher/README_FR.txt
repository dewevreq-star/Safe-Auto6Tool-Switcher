SAFE AUTO TOOL SWITCHER — SOURCE 0.1.0
Minecraft Java 26.3 / Fabric / client-side

IMPORTANT : prototype source NON COMPILÉ et NON TESTÉ. Aucun .jar prêt à installer.
Les API/mappings exacts de Minecraft 26.3 peuvent nécessiter des corrections. Fais une
copie de ton monde avant tout essai.

Fonctions visées : recherche d'outil dans les 36 emplacements, choix selon la vitesse de
casse, permutation temporaire avec la case active, restauration au relâchement du clic,
et blocage de la poursuite du minage si la cible change pendant le maintien.

Compilation Windows :
1. Installe un JDK 25.
2. Installe IntelliJ IDEA Community.
3. Ouvre ce dossier comme projet Gradle.
4. Choisis JDK 25 pour Gradle dans les paramètres IntelliJ.
5. Lance la tâche Gradle 'build'.
6. Si la compilation réussit, le JAR sera dans build/libs/.

Si Gradle échoue, envoie-moi le texte complet de la première erreur rouge. Je pourrai
adapter le projet. N'installe pas le prototype dans un monde important avant validation.
Vérifie également que ton profil Lunar 26.3 accepte les mods Fabric personnalisés.
