package fr.safeautotoolswitcher.mixin;

import fr.safeautotoolswitcher.SafeMiningGuard;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMiningMixin {
    @Inject(method = "continueAttack", at = @At("HEAD"), cancellable = true)
    private void safeAutoToolSwitcher$stopAfterTargetChanges(boolean leftClick, CallbackInfo ci) {
        if (SafeMiningGuard.shouldCancel((Minecraft) (Object) this)) ci.cancel();
    }
}
