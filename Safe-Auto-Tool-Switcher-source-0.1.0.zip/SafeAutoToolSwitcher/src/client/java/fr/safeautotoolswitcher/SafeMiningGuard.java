package fr.safeautotoolswitcher;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

public final class SafeMiningGuard {
    private static BlockPos firstTarget;
    private static boolean blocked;
    private SafeMiningGuard() {}
    public static boolean isBlocked() { return blocked; }
    public static void reset() { firstTarget = null; blocked = false; }

    public static boolean shouldCancel(Minecraft mc) {
        if (mc.player == null || !mc.options.keyAttack.isDown()) { reset(); return false; }
        if (blocked) return true;
        if (!(mc.hitResult instanceof BlockHitResult hit) || mc.hitResult.getType() != HitResult.Type.BLOCK) return false;
        BlockPos current = hit.getBlockPos();
        if (firstTarget == null) { firstTarget = current.immutable(); return false; }
        if (!firstTarget.equals(current)) { blocked = true; return true; }
        return false;
    }
}
