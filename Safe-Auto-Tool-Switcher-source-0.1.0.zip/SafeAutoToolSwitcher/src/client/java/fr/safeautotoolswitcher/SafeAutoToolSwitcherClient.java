package fr.safeautotoolswitcher;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

public final class SafeAutoToolSwitcherClient implements ClientModInitializer {
    private static int originalSlot = -1;
    private static int swappedInventoryIndex = -1;
    private static boolean active;

    @Override public void onInitializeClient() {
        ClientTickEvents.START_CLIENT_TICK.register(SafeAutoToolSwitcherClient::tick);
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.gameMode == null) {
            restore(mc); SafeMiningGuard.reset(); return;
        }
        if (!mc.options.keyAttack.isDown()) {
            restore(mc); SafeMiningGuard.reset(); return;
        }
        if (SafeMiningGuard.isBlocked()) return;
        if (!(mc.hitResult instanceof BlockHitResult hit) || mc.hitResult.getType() != HitResult.Type.BLOCK) return;
        if (!active) { originalSlot = mc.player.getInventory().selected; active = true; }

        BlockState state = mc.level.getBlockState(hit.getBlockPos());
        int best = findBestTool(mc, state);
        if (best < 0) return;
        if (best < 9) {
            if (swappedInventoryIndex >= 9) restoreSwap(mc);
            mc.player.getInventory().selected = best;
        } else if (swappedInventoryIndex != best) {
            if (swappedInventoryIndex >= 9) restoreSwap(mc);
            int selected = mc.player.getInventory().selected;
            mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, best, selected,
                net.minecraft.world.inventory.ClickType.SWAP, mc.player);
            swappedInventoryIndex = best;
        }
    }

    private static int findBestTool(Minecraft mc, BlockState state) {
        int bestIndex = -1; float bestSpeed = 1.0F;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (stack.isEmpty()) continue;
            float speed = stack.getDestroySpeed(state);
            if (speed > bestSpeed) { bestSpeed = speed; bestIndex = i; }
        }
        return bestIndex;
    }

    private static void restoreSwap(Minecraft mc) {
        if (mc.player == null || mc.gameMode == null || swappedInventoryIndex < 9) return;
        int selected = mc.player.getInventory().selected;
        mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, swappedInventoryIndex,
            selected, net.minecraft.world.inventory.ClickType.SWAP, mc.player);
        swappedInventoryIndex = -1;
    }

    private static void restore(Minecraft mc) {
        if (mc.player == null) { originalSlot = -1; swappedInventoryIndex = -1; active = false; return; }
        restoreSwap(mc);
        if (active && originalSlot >= 0 && originalSlot < 9) mc.player.getInventory().selected = originalSlot;
        originalSlot = -1; active = false;
    }
}
